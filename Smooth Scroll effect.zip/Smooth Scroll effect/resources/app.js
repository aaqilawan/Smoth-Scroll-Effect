function smoothScrooll(target, duration) {
    let targets = document.querySelector(target);
    let targetPosition  = targets.getBoundingClientRect().top;
    let startPosition = window.pageYOffset;
    let distance = targetPosition - startPosition;
    let startTime = null;

    function animation(currentTime){
     if(startTime === null){
         startTime = currentTime;
     } 

     let Elapsed = currentTime - startTime;
     let start = ease(Elapsed,startPosition,distance,duration);
     window.scrollTo(0,start);
     if(Elapsed < duration){
        requestAnimationFrame(animation);
     }
    }

    // funtion get from gizma.com/easing
    function ease(t, b, c, d) {
        t /= d/2;
        if (t < 1) return c/2*t*t + b;
        t--;
        return -c/2 * (t*(t-2) - 1) + b;
    }

    requestAnimationFrame(animation);

}

// Add lisner to run 
let listner = document.querySelector('.section-1');
let listner2 = document.querySelector('.section-2');
listner2.addEventListener('click',() =>{
    smoothScrooll('.section-1',1000);
})
listner.addEventListener('click',() =>{
    smoothScrooll('.section-2',1000);
})
